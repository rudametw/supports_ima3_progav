void myfun()
{
  // Empty here
}

int main(void)
{
  myfun();
  return 0;
}
